let IDWTD = {
    vprok: {},
    vkusvill: {},
}